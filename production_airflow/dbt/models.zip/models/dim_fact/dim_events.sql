SELECT
    event_id,
    event_name,
    location,
    duration,
    fee,
    event_date,
    created_at,
    TIMESTAMP_TRUNC(created_at, DAY) as created_date
FROM {{ ref('prep_events') }}