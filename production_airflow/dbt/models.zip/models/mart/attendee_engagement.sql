SELECT
    a.attendee_id,
    a.attendee_name,
    COUNT(DISTINCT r.event_id) as total_events_registered,
    COUNT(DISTINCT CASE WHEN r.payment_status = 'Paid' THEN r.event_id END) as total_events_paid,
    SUM(CASE WHEN r.payment_status = 'Paid' THEN e.fee ELSE 0 END) as total_spent,
    MIN(r.registration_date) as first_registration_date,
    MAX(r.registration_date) as last_registration_date
FROM {{ ref('dim_attendees') }} a
LEFT JOIN {{ ref('fact_registrations') }} r ON a.attendee_id = r.attendee_id
LEFT JOIN {{ ref('dim_events') }} e ON r.event_id = e.event_id
GROUP BY 1, 2