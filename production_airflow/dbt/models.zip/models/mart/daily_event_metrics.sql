SELECT
    TIMESTAMP_TRUNC(TIMESTAMP(e.event_date), DAY) AS date,
    e.event_id,
    e.event_name,
    COUNT(DISTINCT r.registration_id) AS total_registrations,
    COUNT(DISTINCT CASE WHEN r.payment_status = 'Paid' THEN r.registration_id END) AS paid_registrations,
    SUM(CASE WHEN r.payment_status = 'Paid' THEN e.fee ELSE 0 END) AS total_revenue
FROM {{ ref('dim_events') }} e
LEFT JOIN {{ ref('fact_registrations') }} r ON e.event_id = r.event_id
GROUP BY 1, 2, 3